const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost:27017/dbName', {useNewUrlParser: true, useUnifiedTopology: true})
.then(() => {
    console.log("Connection done!");
})
.catch( err => {
    console.log("Connection failed!");
    console.log(err);
})

const movieShema = new mongoose.Schema({
    title: String,
    year: Number,
    score: Number,
    rating: String
});

const Movie = mongoose.model('Movie', movieShema);
const amadeus = new Movie({title: 'Amedeus', year:1986, score: 9.2, rating:'R'});

Movie.insertMany([
    {title: 'Amelie', year:2001, score: 8.3, rating:'R'},
    {title: 'Ali', year:2001, score: 8.3, rating:'R'},
    {title: 'Veli', year:2001, score: 8.3, rating:'R'},
    {title: 'Deli', year:2001, score: 8.3, rating:'R'},
    {title: 'Keli', year:2001, score: 8.3, rating:'R'},
]).then(data => {
    console.log("It worked!");
    console.log(data);
})
.catch( err => {
    console.log("It failed!");
    console.log(err);
})